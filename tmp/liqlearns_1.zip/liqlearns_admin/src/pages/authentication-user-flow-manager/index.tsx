import React, { useState, useEffect } from 'react';
import { UserCheck, Mail, Lock, AlertCircle, CheckCircle, TrendingUp, Users, Shield } from 'lucide-react';
import { supabase } from '../../services/supabaseClient';
import Button from '../../components/ui/Button';

interface AuthMetrics {
  signUpAttempts: number;
  signUpSuccesses: number;
  signUpFailures: number;
  loginAttempts: number;
  loginSuccesses: number;
  passwordResetRequests: number;
  emailVerificationsSent: number;
  activeUsers: number;
}

interface RecentAuthIssue {
  id: string;
  type: 'signup' | 'login' | 'password_reset';
  email: string;
  error: string;
  timestamp: Date;
  resolved: boolean;
}

const AuthenticationUserFlowManager: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState<AuthMetrics>({
    signUpAttempts: 0,
    signUpSuccesses: 0,
    signUpFailures: 0,
    loginAttempts: 0,
    loginSuccesses: 0,
    passwordResetRequests: 0,
    emailVerificationsSent: 0,
    activeUsers: 0
  });
  const [recentIssues, setRecentIssues] = useState<RecentAuthIssue[]>([]);
  const [authFlowStatus, setAuthFlowStatus] = useState({
    signupEnabled: true,
    emailVerificationRequired: true,
    passwordResetEnabled: true,
    twoFactorEnabled: true,
    rateLimitingEnabled: true
  });

  useEffect(() => {
    fetchAuthMetrics();
    fetchRecentIssues();
  }, []);

  const fetchAuthMetrics = async () => {
    setLoading(true);
    try {
      // Fetch active users count
      const { count: activeCount } = await supabase
        .from('user_profiles')
        .select('*', { count: 'exact', head: true })
        .eq('account_status', 'active');

      // Fetch security audit logs for auth metrics
      const { data: securityLogs } = await supabase
        .from('security_audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1000);

      // Calculate metrics from security logs
      const signUpAttempts = securityLogs?.filter(log => log.event_type === 'signup_attempt').length || 0;
      const signUpSuccesses = securityLogs?.filter(log => log.event_type === 'signup_attempt' && log.success).length || 0;
      const loginAttempts = securityLogs?.filter(log => log.event_type === 'login_attempt').length || 0;
      const loginSuccesses = securityLogs?.filter(log => log.event_type === 'login_attempt' && log.success).length || 0;

      // Fetch password reset requests
      const { count: passwordResetCount } = await supabase
        .from('email_verifications')
        .select('*', { count: 'exact', head: true })
        .order('created_at', { ascending: false })
        .limit(100);

      // Fetch email verifications sent
      const { count: emailVerificationCount } = await supabase
        .from('email_verifications')
        .select('*', { count: 'exact', head: true })
        .eq('verified', false);

      setMetrics({
        signUpAttempts,
        signUpSuccesses,
        signUpFailures: signUpAttempts - signUpSuccesses,
        loginAttempts,
        loginSuccesses,
        passwordResetRequests: passwordResetCount || 0,
        emailVerificationsSent: emailVerificationCount || 0,
        activeUsers: activeCount || 0
      });
    } catch (error) {
      console.error('Error fetching auth metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentIssues = async () => {
    try {
      // Fetch recent failed auth attempts
      const { data: failedAttempts } = await supabase
        .from('security_audit_logs')
        .select('*')
        .eq('success', false)
        .order('created_at', { ascending: false })
        .limit(10);

      if (failedAttempts) {
        const issues: RecentAuthIssue[] = failedAttempts.map(attempt => ({
          id: attempt.id,
          type: attempt.event_type === 'signup_attempt' ? 'signup' : 'login',
          email: attempt.event_description || 'Unknown',
          error: attempt.event_description || 'Unknown error',
          timestamp: new Date(attempt.created_at),
          resolved: false
        }));

        setRecentIssues(issues);
      }
    } catch (error) {
      console.error('Error fetching recent issues:', error);
    }
  };

  const handleTestSignup = async () => {
    try {
      // Test signup flow
      const testEmail = `test-${Date.now()}@example.com`;
      const { data, error } = await supabase.auth.signUp({
        email: testEmail,
        password: 'TestPassword123!',
        options: {
          emailRedirectTo: `${window.location.origin}/login`
        }
      });

      if (error) {
        alert(`Signup test failed: ${error.message}`);
      } else {
        alert(`✅ Signup test successful! User created: ${data.user?.email}`);
      }
    } catch (error: any) {
      alert(`❌ Signup test error: ${error.message}`);
    }
  };

  const handleTestPasswordReset = async () => {
    try {
      const testEmail = 'demo@liqlearns.com';
      const { error } = await supabase.auth.resetPasswordForEmail(testEmail, {
        redirectTo: `${window.location.origin}/reset-password`
      });

      if (error) {
        alert(`Password reset test failed: ${error.message}`);
      } else {
        alert(`✅ Password reset email sent to ${testEmail}`);
      }
    } catch (error: any) {
      alert(`❌ Password reset test error: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-12 h-12 text-orange-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">Loading authentication metrics...</p>
        </div>
      </div>
    );
  }

  const successRate = metrics.signUpAttempts > 0 
    ? Math.round((metrics.signUpSuccesses / metrics.signUpAttempts) * 100) 
    : 100;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Authentication & User Flow Manager
              </h1>
              <p className="text-gray-600">
                Sign-up, login, password recovery monitoring and comprehensive authentication oversight
              </p>
            </div>
            <Button onClick={fetchAuthMetrics} iconName="RefreshCw">
              Refresh Metrics
            </Button>
          </div>
        </div>

        {/* Success Rate Banner */}
        <div className={`rounded-lg shadow-sm border p-6 ${
          successRate >= 95 
            ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-200'
            : successRate >= 80
            ? 'bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200' :'bg-gradient-to-r from-red-50 to-rose-50 border-red-200'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <TrendingUp className={`w-10 h-10 ${
                successRate >= 95 ? 'text-green-600' : successRate >= 80 ? 'text-yellow-600' : 'text-red-600'
              }`} />
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {successRate}% Success Rate
                </h2>
                <p className="text-gray-700">
                  {metrics.signUpSuccesses} successful signups out of {metrics.signUpAttempts} attempts
                </p>
              </div>
            </div>
            {successRate >= 95 ? (
              <CheckCircle className="w-8 h-8 text-green-600" />
            ) : (
              <AlertCircle className="w-8 h-8 text-yellow-600" />
            )}
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <UserCheck className="w-6 h-6 text-blue-500" />
              <span className="text-2xl font-bold text-gray-900">{metrics.signUpSuccesses}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">Successful Sign-ups</h3>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <AlertCircle className="w-6 h-6 text-red-500" />
              <span className="text-2xl font-bold text-gray-900">{metrics.signUpFailures}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">Failed Sign-ups</h3>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <Lock className="w-6 h-6 text-green-500" />
              <span className="text-2xl font-bold text-gray-900">{metrics.passwordResetRequests}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">Password Resets</h3>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <Users className="w-6 h-6 text-purple-500" />
              <span className="text-2xl font-bold text-gray-900">{metrics.activeUsers}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">Active Users</h3>
          </div>
        </div>

        {/* Authentication Flow Status */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900">Authentication Flow Status</h2>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(authFlowStatus).map(([key, value]) => (
              <div
                key={key}
                className={`p-4 rounded-lg border ${
                  value 
                    ? 'bg-green-50 border-green-200' :'bg-red-50 border-red-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </span>
                  {value ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-600" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Authentication Issues */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900">Recent Authentication Issues</h2>
          </div>
          <div className="p-6">
            {recentIssues.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                <p className="text-gray-600">No recent authentication issues detected</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentIssues.slice(0, 5).map((issue) => (
                  <div
                    key={issue.id}
                    className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded">
                          {issue.type.toUpperCase()}
                        </span>
                        <span className="text-sm text-gray-600">
                          {issue.timestamp.toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-800 font-medium">{issue.email}</p>
                      <p className="text-xs text-gray-600 mt-1">{issue.error}</p>
                    </div>
                    <AlertCircle className="w-5 h-5 text-red-500 ml-4" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Test Controls */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Authentication Testing</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button onClick={handleTestSignup} iconName="UserCheck">
              Test Sign-up Flow
            </Button>
            <Button onClick={handleTestPasswordReset} iconName="Mail" variant="outline">
              Test Password Reset
            </Button>
          </div>
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Testing Guidelines:</strong> Use test endpoints to verify authentication flows without affecting production data. All test users are automatically cleaned up after 24 hours.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthenticationUserFlowManager;