import React from 'react';

const StatisticsSection: React.FC = () => {
  return null;
};

export default StatisticsSection;