import React from 'react';

const TestimonialsSection: React.FC = () => {
  return null;
};

export default TestimonialsSection;