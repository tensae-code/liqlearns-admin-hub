import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import LogoAnimation from './components/LogoAnimation';
import LoadingProgress from './components/LoadingProgress';
import EducationalTips from './components/EducationalTips';

const LoadingScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user, userProfile, loading: authLoading } = useAuth();
  const [progress, setProgress] = useState(0);
  const [minDisplayTime, setMinDisplayTime] = useState(false);

  useEffect(() => {
    // Simulate loading progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    // Ensure minimum display time of 2 seconds for better UX
    const minTimer = setTimeout(() => {
      setMinDisplayTime(true);
    }, 2000);

    return () => {
      clearInterval(interval);
      clearTimeout(minTimer);
    };
  }, []);

  // Navigate when both conditions are met:
  // 1. Progress is 100%
  // 2. User is authenticated (userProfile will load after navigation)
  // 3. Minimum display time has passed
  useEffect(() => {
    if (progress === 100 && user && minDisplayTime && !authLoading) {
      setTimeout(() => {
        navigate('/role-based-dashboard-hub', { replace: true });
      }, 500);
    }
  }, [progress, user, minDisplayTime, authLoading, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <LogoAnimation />
        <LoadingProgress progress={progress} />
        <EducationalTips />
      </div>
    </div>
  );
};

export default LoadingScreen;