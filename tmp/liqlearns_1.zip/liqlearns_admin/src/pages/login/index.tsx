import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import LoginForm from './components/LoginForm';
import LoginFooter from './components/LoginFooter';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import GeneralQuestionsStep from './components/GeneralQuestionsStep';
import PasswordStrengthIndicator from '../../components/ui/PasswordStrengthIndicator';
import PhoneInput from '../../components/ui/PhoneInput';
import { Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react';
import RoleSelectionStep from './components/RoleSelectionStep';
import LoginHeader from './components/LoginHeader';
import { apiClient } from '../../lib/apiClient';
import { useNavigate } from 'react-router-dom';

// Add countryCodes array
const countryCodes = [
  { code: 'ET', country: 'Ethiopia', flag: '🇪🇹', dialCode: '+251' },
  { code: 'US', country: 'United States', flag: '🇺🇸', dialCode: '+1' },
  { code: 'GB', country: 'United Kingdom', flag: '🇬🇧', dialCode: '+44' },
  { code: 'CA', country: 'Canada', flag: '🇨🇦', dialCode: '+1' },
  { code: 'AU', country: 'Australia', flag: '🇦🇺', dialCode: '+61' },
  { code: 'DE', country: 'Germany', flag: '🇩🇪', dialCode: '+49' },
  { code: 'FR', country: 'France', flag: '🇫🇷', dialCode: '+33' },
  { code: 'IT', country: 'Italy', flag: '🇮🇹', dialCode: '+39' },
  { code: 'ES', country: 'Spain', flag: '🇪🇸', dialCode: '+34' },
  { code: 'IN', country: 'India', flag: '🇮🇳', dialCode: '+91' },
  { code: 'CN', country: 'China', flag: '🇨🇳', dialCode: '+86' },
  { code: 'JP', country: 'Japan', flag: '🇯🇵', dialCode: '+81' },
  { code: 'BR', country: 'Brazil', flag: '🇧🇷', dialCode: '+55' },
  { code: 'MX', country: 'Mexico', flag: '🇲🇽', dialCode: '+52' },
  { code: 'ZA', country: 'South Africa', flag: '🇿🇦', dialCode: '+27' },
  { code: 'KE', country: 'Kenya', flag: '🇰🇪', dialCode: '+254' },
  { code: 'NG', country: 'Nigeria', flag: '🇳🇬', dialCode: '+234' },
  { code: 'EG', country: 'Egypt', flag: '🇪🇬', dialCode: '+20' },
  { code: 'AE', country: 'UAE', flag: '🇦🇪', dialCode: '+971' },
  { code: 'SA', country: 'Saudi Arabia', flag: '🇸🇦', dialCode: '+966' }
];

const LoginPage: React.FC = () => {
  const { user, loading: authLoading, signUp, sendTwoFactorCode, verifyTwoFactorCode, sendEmailOTP, verifyEmailOTP, signIn } = useAuth();
  const navigate = useNavigate();

  // Step management: 1=Login, 2-5=Signup steps (Role, Basic Info, General Questions, Verification)
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    role: 'student',
    email: '',
    username: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    country: 'ET',
    state: '',
    city: '',
    sponsorName: '',
    verificationType: 'phone\' as \'phone\' | \'email'
  });
  
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [twoFactorVerified, setTwoFactorVerified] = useState(false);
  const [showVerificationInput, setShowVerificationInput] = useState(false);
  const [countryCode, setCountryCode] = useState('ET');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [usernameError, setUsernameError] = useState('');

  const [usernameAvailabilityStatus, setUsernameAvailabilityStatus] = useState<'checking' | 'available' | 'taken' | null>(null);
  const [emailAvailabilityStatus, setEmailAvailabilityStatus] = useState<'checking' | 'available' | 'taken' | null>(null);
  const [usernameCheckTimeout, setUsernameCheckTimeout] = useState<NodeJS.Timeout | null>(null);
  const [emailCheckTimeout, setEmailCheckTimeout] = useState<NodeJS.Timeout | null>(null);
  const [sponsorError, setSponsorError] = useState('');
  const [sponsorValidationStatus, setSponsorValidationStatus] = useState<'checking' | 'valid' | 'invalid' | null>(null);
  const [sponsorCheckTimeout, setSponsorCheckTimeout] = useState<NodeJS.Timeout | null>(null);

  // Instagram-like username validation
  const validateUsername = (username: string): { isValid: boolean; error: string } => {
    username = username.trim();
    
    if (username.length < 3) {
      return { isValid: false, error: 'Username must be at least 3 characters' };
    }
    if (username.length > 30) {
      return { isValid: false, error: 'Username must be 30 characters or less' };
    }
    
    const validPattern = /^[a-zA-Z0-9._]+$/;
    if (!validPattern.test(username)) {
      return { isValid: false, error: 'Username can only contain letters, numbers, periods, and underscores' };
    }
    
    if (username.startsWith('.') || username.endsWith('.')) {
      return { isValid: false, error: 'Username cannot start or end with a period' };
    }
    
    if (username.includes('..')) {
      return { isValid: false, error: 'Username cannot have consecutive periods' };
    }
    
    if (!/^[a-zA-Z0-9]/.test(username)) {
      return { isValid: false, error: 'Username must start with a letter or number' };
    }
    
    return { isValid: true, error: '' };
  };

  const checkEmailAvailability = async (email: string) => {
    if (email.length < 5 || !email.includes('@')) {
      setEmailAvailabilityStatus(null);
      return;
    }

    setEmailAvailabilityStatus('checking');

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('email')
        .eq('email', email.toLowerCase())
        .maybeSingle();

      if (error) throw error;
      setEmailAvailabilityStatus(data ? 'taken' : 'available');
    } catch (error) {
      console.error('Error checking email:', error);
      setEmailAvailabilityStatus(null);
    }
  };

  const checkUsernameAvailability = async (username: string) => {
    if (username.length < 3) {
      setUsernameAvailabilityStatus(null);
      return;
    }

    setUsernameAvailabilityStatus('checking');

    try {
      const response = await apiClient.post('/functions/v1/check-username', { 
        username: username.toLowerCase() 
      });

      if (response.error) {
        console.error('Error checking username:', response.error);
        setUsernameAvailabilityStatus(null);
        return;
      }

      setUsernameAvailabilityStatus(response.data.exists ? 'taken' : 'available');
    } catch (error) {
      console.error('Error checking username:', error);
      setUsernameAvailabilityStatus(null);
    }
  };

  const checkSponsorUsername = async (sponsorName: string) => {
    if (sponsorName.length < 3) {
      setSponsorValidationStatus(null);
      setSponsorError('');
      return;
    }

    setSponsorValidationStatus('checking');
    setSponsorError('');

    try {
      const response = await apiClient.post('/functions/v1/check-sponsor', { 
        username: sponsorName.toLowerCase() 
      });

      if (response.error) {
        console.error('Error checking sponsor:', response.error);
        setSponsorValidationStatus(null);
        setSponsorError('Error validating sponsor username. Please try again.');
        return;
      }

      if (response.data.exists) {
        if (response.data.allowed) {
          setSponsorValidationStatus('valid');
          setSponsorError('');
        } else {
          setSponsorValidationStatus('invalid');
          setSponsorError('Admins & support cannot sponsor');
        }
      } else {
        setSponsorValidationStatus('invalid');
        setSponsorError('Sponsor username not found');
      }
    } catch (error) {
      console.error('Error checking sponsor username:', error);
      setSponsorValidationStatus(null);
      setSponsorError('Error validating sponsor username. Please try again.');
    }
  };

  const handleInputChange = (field: string, value: string) => {
    if (field === 'username') {
      const validation = validateUsername(value);
      setUsernameError(validation.error);

      if (usernameCheckTimeout) {
        clearTimeout(usernameCheckTimeout);
      }

      if (validation.isValid && value.length >= 3) {
        const timeout = setTimeout(() => {
          checkUsernameAvailability(value);
        }, 400);
        setUsernameCheckTimeout(timeout);
      } else {
        setUsernameAvailabilityStatus(null);
      }
    }

    if (field === 'email') {
      if (emailCheckTimeout) {
        clearTimeout(emailCheckTimeout);
      }

      if (value.length >= 5 && value.includes('@')) {
        const timeout = setTimeout(() => {
          checkEmailAvailability(value);
        }, 500);
        setEmailCheckTimeout(timeout);
      } else {
        setEmailAvailabilityStatus(null);
      }
    }
    
    if (field === 'sponsorName') {
      if (sponsorCheckTimeout) {
        clearTimeout(sponsorCheckTimeout);
      }

      if (value.length >= 3) {
        const timeout = setTimeout(() => {
          checkSponsorUsername(value);
        }, 400);
        setSponsorCheckTimeout(timeout);
      } else {
        setSponsorValidationStatus(null);
        setSponsorError('');
      }
    }
    
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    setError('');
  };

  const handleSendCode = async () => {
    if (formData.verificationType === 'phone') {
      if (!formData.phone) {
        setError('Please enter a phone number');
        return;
      }
      
      const selectedCountry = countryCodes.find(c => c.code === countryCode);
      const fullPhoneNumber = `${selectedCountry?.dialCode}${formData.phone}`;
      
      setIsLoading(true);
      const { error } = await sendTwoFactorCode(fullPhoneNumber);
      setIsLoading(false);
      
      if (error) {
        setError(error.message);
      } else {
        setShowVerificationInput(true);
      }
    } else {
      if (!formData.email) {
        setError('Please enter an email address');
        return;
      }
      
      setIsLoading(true);
      const { error } = await sendEmailOTP(formData.email);
      setIsLoading(false);
      
      if (error) {
        setError(error.message);
      } else {
        setShowVerificationInput(true);
      }
    }
  };

  const handleVerifyCode = async () => {
    if (twoFactorCode.length !== 6) {
      setError('Please enter a 6-digit code');
      return;
    }
    
    if (twoFactorVerified) {
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    if (formData.verificationType === 'phone') {
      const selectedCountry = countryCodes.find(c => c.code === countryCode);
      const fullPhoneNumber = `${selectedCountry?.dialCode}${formData.phone}`;
      
      const { error, verified } = await verifyTwoFactorCode(fullPhoneNumber, twoFactorCode);
      setIsLoading(false);
      
      if (error || !verified) {
        setError('Invalid or expired code. Please request a new code if needed.');
      } else {
        setTwoFactorVerified(true);
        setError('');
      }
    } else {
      const { error, verified } = await verifyEmailOTP(formData.email, twoFactorCode);
      setIsLoading(false);
      
      if (error || !verified) {
        setError(error.message || 'Invalid or expired code. Please request a new code if needed.');
      } else {
        setTwoFactorVerified(true);
        setError('');
      }
    }
  };

  const handleLogin = async (loginFormData: any) => {
    // Login handler - this would contain actual login logic
    try {
      setIsLoading(true);
      setError('');
      // Login logic would go here
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUpNext = () => {
    // Validation for each signup step
    if (currentStep === 2 && !formData.role) {
      setError('Please select a role');
      return;
    }
    
    if (currentStep === 3) {
      if (!formData.email || !formData.username || !formData.password || !formData.confirmPassword || !formData.fullName) {
        setError('All fields are required');
        return;
      }
      
      const usernameValidation = validateUsername(formData.username);
      if (!usernameValidation.isValid) {
        setError(usernameValidation.error);
        return;
      }

      if (usernameAvailabilityStatus === 'taken') {
        setError('Username is already taken. Please choose another one.');
        return;
      }

      if (usernameAvailabilityStatus === 'checking') {
        setError('Please wait while we check username availability');
        return;
      }

      if (emailAvailabilityStatus === 'taken') {
        setError('Email is already registered. Please use another email.');
        return;
      }

      if (emailAvailabilityStatus === 'checking') {
        setError('Please wait while we check email availability');
        return;
      }
      
      if (formData.password !== formData.confirmPassword) {
        setError('Passwords do not match');
        return;
      }
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters');
        return;
      }

      if (!formData.sponsorName) {
        setError('Sponsor username is required');
        return;
      }

      if (sponsorValidationStatus === 'checking') {
        setError('Please wait while we validate the sponsor username');
        return;
      }

      if (sponsorValidationStatus === 'invalid') {
        setError(sponsorError || 'Invalid sponsor username. Please provide a valid sponsor username.');
        return;
      }

      if (sponsorValidationStatus !== 'valid') {
        setError('Please provide a valid sponsor username');
        return;
      }
    }
    
    if (currentStep === 4 && (!formData.dateOfBirth || !formData.address || !formData.country || !formData.city)) {
      setError('Please fill in all fields');
      return;
    }
    if (currentStep === 4 && formData.country && formData.country !== 'ET' && !formData.state) {
      setError('Please select a state/province');
      return;
    }
    if (currentStep === 5 && !twoFactorVerified) {
      setError('Please verify your identity first');
      return;
    }
    
    setError('');
    
    if (currentStep === 5) {
      handleSignUpSubmit();
      return;
    }

    setCurrentStep(currentStep + 1);
  };

  const handleSignUpSubmit = async () => {
    try {
      setIsLoading(true);
      
      const fullPhoneNumber = formData.phone;
      
      const metadata = {
        full_name: formData.fullName,
        username: formData.username,
        phone: fullPhoneNumber,
        role: formData.role,
        date_of_birth: formData.dateOfBirth,
        address: formData.address,
        country: formData.country,
        state: formData.state,
        city: formData.city,
        sponsor_name: formData.sponsorName
      };

      const { error: signupError } = await signUp(formData.email, formData.password, { data: metadata });
      
      if (signupError) throw signupError;

      window.location.href = '/login';
    } catch (error: any) {
      console.error('Signup error:', error);
      if (error?.message?.includes('Database error saving new user')) {
        setError('We could not finish creating your account. Please verify your details or contact support.');
      } else {
        setError(error.message || 'Failed to create account. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      setError('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const result = await signIn(formData.email, formData.password);
      
      if (result.error) {
        throw result.error;
      }

      // Show loading screen during navigation
      navigate('/loading-screen', { replace: true });
    } catch (err: any) {
      console.error('Sign in error:', err);
      setError(err?.message || 'Failed to sign in. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  // FIXED: Total steps = 4 for signup flow (Role → Basic Info → Questions → Verification)
  const totalSteps = 4;
  const signupStepNumber = currentStep - 1; // currentStep 2-5 maps to steps 1-4
  
  // Step labels for better UX
  const stepLabels = ['Role', 'Basic Info', 'Questions', 'Verification'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        <LoginHeader />

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-red-800">{error}</p>
                <button
                  onClick={() => navigator.clipboard.writeText(error)}
                  className="text-xs text-red-600 hover:text-red-800 mt-1 underline"
                >
                  Copy error details
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Step 1: Login Form */}
        {currentStep === 1 && (
          <LoginForm
            formData={formData}
            setFormData={setFormData}
            isLoading={isLoading}
            onSubmit={handleSignIn}
            onSwitchToSignUp={() => setCurrentStep(2)}
          />
        )}

        {/* Signup Steps (2-5) */}
        {currentStep >= 2 && (
          <div className="space-y-6">
            {/* FIXED: Progress indicator showing exactly 4 steps with descriptive labels */}
            <div className="mb-8">
              <div className="flex items-center justify-between gap-2">
                {Array.from({ length: totalSteps }).map((_, index) => {
                  const stepNum = index + 1;
                  const isActive = signupStepNumber === stepNum;
                  const isCompleted = signupStepNumber > stepNum;
                  
                  return (
                    <React.Fragment key={stepNum}>
                      <div className="flex flex-col items-center min-w-0 flex-shrink-0">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300 ${
                            isActive
                              ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg scale-110 ring-4 ring-orange-200'
                              : isCompleted
                              ? 'bg-green-500 text-white shadow-md'
                              : 'bg-gray-200 text-gray-400'
                          }`}
                        >
                          {stepNum}
                        </div>
                        <span className={`text-xs mt-1.5 whitespace-nowrap font-medium ${isActive ? 'text-orange-600' : 'text-gray-500'}`}>
                          {stepLabels[index]}
                        </span>
                      </div>
                      {stepNum < totalSteps && (
                        <div className="flex-1 h-1 mx-1 bg-gray-200 rounded-full overflow-hidden min-w-[24px] max-w-[40px]">
                          <div
                            className={`h-full transition-all duration-300 rounded-full ${isCompleted ? 'bg-green-500 w-full' : 'w-0'}`}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Role Selection */}
            {currentStep === 2 && (
              <div>
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Choose Your Role</h3>
                  <p className="text-gray-600">Select how you want to join LiqLearns</p>
                </div>
                <RoleSelectionStep
                  selectedRole={formData.role}
                  onRoleSelect={(role) => handleInputChange('role', role)}
                />
              </div>
            )}

            {/* Step 3: Basic Info */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Basic Information</h3>
                  <p className="text-gray-600">Create your account credentials</p>
                </div>
                
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Username"
                    value={formData.username}
                    onChange={(e) => handleInputChange('username', e.target.value)}
                    autoComplete="off"
                    className={`pr-10 ${usernameError || usernameAvailabilityStatus === 'taken' ? 'border-red-500 focus:ring-red-500' : usernameAvailabilityStatus === 'available' ? 'border-green-500 focus:ring-green-500' : ''}`}
                  />
                  
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                    {usernameAvailabilityStatus === 'checking' && (
                      <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                    )}
                    {usernameAvailabilityStatus === 'available' && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                    {usernameAvailabilityStatus === 'taken' && (
                      <AlertCircle className="w-5 h-5 text-red-500" />
                    )}
                  </div>

                  {usernameError && (
                    <p className="text-xs text-red-500 mt-1">{usernameError}</p>
                  )}
                  {usernameAvailabilityStatus === 'taken' && (
                    <p className="text-xs text-red-500 mt-1">Username is already taken</p>
                  )}
                  {usernameAvailabilityStatus === 'available' && (
                    <p className="text-xs text-green-500 mt-1">Username is available!</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    3-30 characters. Letters, numbers, periods, and underscores only.
                  </p>
                </div>
                
                <div className="relative">
                  <Input
                    type="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    autoComplete="email"
                    className={`pr-10 ${emailAvailabilityStatus === 'taken' ? 'border-red-500 focus:ring-red-500' : emailAvailabilityStatus === 'available' ? 'border-green-500 focus:ring-green-500' : ''}`}
                  />
                  
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                    {emailAvailabilityStatus === 'checking' && (
                      <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                    )}
                    {emailAvailabilityStatus === 'available' && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                    {emailAvailabilityStatus === 'taken' && (
                      <AlertCircle className="w-5 h-5 text-red-500" />
                    )}
                  </div>

                  {emailAvailabilityStatus === 'taken' && (
                    <p className="text-xs text-red-500 mt-1">Email is already registered</p>
                  )}
                  {emailAvailabilityStatus === 'available' && (
                    <p className="text-xs text-green-500 mt-1">Email is available!</p>
                  )}
                </div>
                
                <Input
                  type="text"
                  placeholder="Full Name"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  autoComplete="name"
                  name="fullName"
                />
                
                <div>
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="pr-10"
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  <div className="mt-3">
                    <PasswordStrengthIndicator password={formData.password} />
                  </div>
                </div>
                
                <div className="relative">
                  <Input
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="Confirm Password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                    className="pr-10"
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Sponsor/Referrer Username *
                  </label>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Enter sponsor's username"
                      value={formData.sponsorName}
                      onChange={(e) => handleInputChange('sponsorName', e.target.value)}
                      autoComplete="off"
                      className={`pr-10 ${sponsorError || sponsorValidationStatus === 'invalid' ? 'border-red-500 focus:ring-red-500' : sponsorValidationStatus === 'valid' ? 'border-green-500 focus:ring-green-500' : ''}`}
                      required
                    />
                    
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                      {sponsorValidationStatus === 'checking' && (
                        <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                      )}
                      {sponsorValidationStatus === 'valid' && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                      {sponsorValidationStatus === 'invalid' && (
                        <AlertCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </div>

                  {sponsorError && (
                    <p className="text-xs text-red-500 mt-1">{sponsorError}</p>
                  )}
                  {sponsorValidationStatus === 'valid' && (
                    <p className="text-xs text-green-500 mt-1">Sponsor username verified!</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Required: Enter the username of the person who referred you
                  </p>
                </div>
              </div>
            )}

            {/* Step 4: General Questions */}
            {currentStep === 4 && (
              <GeneralQuestionsStep
                formData={{
                  address: formData.address,
                  dateOfBirth: formData.dateOfBirth,
                  country: formData.country,
                  state: formData.state,
                  city: formData.city
                }}
                onInputChange={handleInputChange}
              />
            )}

            {/* Step 5: Verification */}
            {currentStep === 5 && (
              <div className="space-y-6">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Identity Verification</h3>
                  <p className="text-gray-600">Choose your preferred verification method</p>
                </div>

                <div className="flex justify-center gap-4 mb-6">
                  <button
                    type="button"
                    onClick={() => {
                      handleInputChange('verificationType', 'phone');
                      setShowVerificationInput(false);
                      setTwoFactorCode('');
                      setTwoFactorVerified(false);
                      setError('');
                    }}
                    className={`px-6 py-3 rounded-xl font-medium transition-all ${
                      formData.verificationType === 'phone' ?'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    📱 Phone Verification
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleInputChange('verificationType', 'email');
                      setShowVerificationInput(false);
                      setTwoFactorCode('');
                      setTwoFactorVerified(false);
                      setError('');
                    }}
                    className={`px-6 py-3 rounded-xl font-medium transition-all ${
                      formData.verificationType === 'email' ?'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    ✉️ Email Verification
                  </button>
                </div>

                {!showVerificationInput ? (
                  <div className="space-y-4">
                    {formData.verificationType === 'phone' ? (
                      <>
                        <PhoneInput
                          value={formData.phone}
                          onChange={(value) => handleInputChange('phone', value)}
                          countryCode={countryCode}
                          onCountryCodeChange={setCountryCode}
                          required
                          placeholder="XXX XXX XXX"
                        />
                        <Button 
                          type="button" 
                          onClick={handleSendCode} 
                          variant="outline" 
                          fullWidth 
                          className="mt-2"
                          disabled={isLoading || !formData.phone}
                        >
                          {isLoading ? 'Sending...' : 'Send Verification Code'}
                        </Button>
                      </>
                    ) : (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                          <Input
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            placeholder="your@email.com"
                            disabled
                            className="bg-gray-50"
                          />
                          <p className="text-xs text-gray-500 mt-1">Using email from step 2</p>
                        </div>
                        <Button 
                          type="button" 
                          onClick={handleSendCode} 
                          variant="outline" 
                          fullWidth 
                          className="mt-2"
                          disabled={isLoading || !formData.email}
                        >
                          {isLoading ? 'Sending...' : 'Send Verification Code'}
                        </Button>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Enter 6-Digit Code</label>
                      <Input
                        type="text"
                        maxLength={6}
                        value={twoFactorCode}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          setTwoFactorCode(value);
                          setError('');
                        }}
                        className="text-center text-2xl tracking-widest"
                        placeholder="000000"
                        disabled={twoFactorVerified}
                      />
                    </div>
                    
                    {twoFactorVerified && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded-xl text-sm text-green-700 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        <span>{formData.verificationType === 'phone' ? 'Phone number' : 'Email'} verified successfully!</span>
                      </div>
                    )}
                    
                    <Button 
                      type="button" 
                      onClick={handleVerifyCode} 
                      variant="default" 
                      fullWidth 
                      className="mt-2"
                      disabled={isLoading || twoFactorCode.length !== 6 || twoFactorVerified}
                    >
                      {twoFactorVerified ? 'Verified ✓' : isLoading ? 'Verifying...' : 'Verify Code'}
                    </Button>
                    
                    {!twoFactorVerified && (
                      <div className="flex flex-col gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setShowVerificationInput(false);
                            setTwoFactorCode('');
                            setTwoFactorVerified(false);
                            setError('');
                          }}
                          className="text-sm text-orange-600 hover:text-orange-700 underline w-full text-center"
                        >
                          Change {formData.verificationType === 'phone' ? 'Phone Number' : 'Email Address'}
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            setTwoFactorCode('');
                            setError('');
                            await handleSendCode();
                          }}
                          className="text-sm text-blue-600 hover:text-blue-700 underline w-full text-center"
                          disabled={isLoading}
                        >
                          {isLoading ? 'Sending...' : 'Resend Code'}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Navigation Buttons for Signup Steps */}
            <div className="flex justify-between items-center pt-6 border-t border-gray-200">
              <Button
                type="button"
                onClick={() => setCurrentStep(currentStep - 1)}
                disabled={currentStep === 2}
                variant="outline"
              >
                ← Previous
              </Button>

              {currentStep < 5 ? (
                <Button
                  type="button"
                  onClick={handleSignUpNext}
                  disabled={isLoading || (currentStep === 3 && (usernameAvailabilityStatus === 'checking' || emailAvailabilityStatus === 'checking'))}
                  variant="default"
                >
                  Next →
                </Button>
              ) : (
                <Button
                  type="button"
                  onClick={handleSignUpSubmit}
                  disabled={isLoading || !twoFactorVerified}
                  variant="default"
                >
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Button>
              )}
            </div>
          </div>
        )}

        <LoginFooter />
      </div>
    </div>
  );
};

export default LoginPage;