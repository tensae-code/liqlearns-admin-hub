import React, { useEffect } from 'react';

const CircularProgress = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: CircularProgress is not implemented yet.');
  }, []);
  return (
    <>
  { /*CircularProgress */} 
 </>
  );
};

export default CircularProgress;
