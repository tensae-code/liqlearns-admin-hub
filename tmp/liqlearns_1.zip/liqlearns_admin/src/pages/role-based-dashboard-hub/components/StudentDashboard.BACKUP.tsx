import React, { useEffect, useState } from 'react';




// Add this block - Import Flame icon
import { Flame } from 'lucide-react';

// ✅ CRITICAL FIX: Import ONLY direct Supabase client - NO edge function dependencies


// ... rest of existing code from StudentDashboard.tsx ...
// (This is a complete backup copy of the original file)