import React, { useState, useEffect } from 'react';
import { supabase } from '../../services/supabaseClient';
import { 
  Activity, 
  Database, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  RefreshCw,
  TrendingUp,
  Users,
  Server,
  Wifi,
  WifiOff
} from 'lucide-react';

interface SystemHealth {
  component: string;
  status: string;
  message: string;
  last_checked: string;
}

interface EnvironmentCheck {
  check_name: string;
  status: string;
  details: string;
}

const SystemIntegrationPerformanceMonitor: React.FC = () => {
  const [systemHealth, setSystemHealth] = useState<SystemHealth[]>([]);
  const [envChecks, setEnvChecks] = useState<EnvironmentCheck[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [realtimeStatus, setRealtimeStatus] = useState<'connected' | 'disconnected'>('disconnected');

  useEffect(() => {
    fetchSystemHealth();
    checkRealtimeConnection();
    
    const interval = setInterval(() => {
      fetchSystemHealth();
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const checkRealtimeConnection = () => {
    const channel = supabase.channel('system-health');
    
    channel
      .on('presence', { event: 'sync' }, () => {
        setRealtimeStatus('connected');
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setRealtimeStatus('connected');
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR') {
          setRealtimeStatus('disconnected');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const fetchSystemHealth = async () => {
    setIsLoading(true);
    setError('');

    try {
      // Fetch system health checks
      const { data: healthData, error: healthError } = await supabase
        .rpc('system_health_check');

      if (healthError) throw healthError;
      setSystemHealth(healthData || []);

      // Fetch environment validation
      const { data: envData, error: envError } = await supabase
        .rpc('validate_environment');

      if (envError) throw envError;
      setEnvChecks(envData || []);

      setLastRefresh(new Date());
    } catch (err: any) {
      console.error('Failed to fetch system health:', err);
      setError(err.message || 'Failed to fetch system health data');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    const normalizedStatus = status?.toUpperCase();
    switch (normalizedStatus) {
      case 'HEALTHY': case'OK':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'WARNING':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'ERROR': case'CRITICAL':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Activity className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    const normalizedStatus = status?.toUpperCase();
    switch (normalizedStatus) {
      case 'HEALTHY': case'OK':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'WARNING':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'ERROR': case'CRITICAL':
        return 'bg-red-50 border-red-200 text-red-800';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Server className="w-8 h-8 text-indigo-600" />
                System Integration & Performance Monitor
              </h1>
              <p className="text-gray-600 mt-2">
                Real-time monitoring of system health, database connections, and integration status
              </p>
            </div>
            <button
              onClick={fetchSystemHealth}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
          <div className="mt-4 flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              {realtimeStatus === 'connected' ? (
                <>
                  <Wifi className="w-4 h-4 text-green-500" />
                  <span className="text-green-600">Realtime Connected</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4 text-red-500" />
                  <span className="text-red-600">Realtime Disconnected</span>
                </>
              )}
            </div>
            <div>
              Last Updated: {lastRefresh.toLocaleTimeString()}
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-start">
              <XCircle className="w-5 h-5 text-red-600 mr-2 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-red-800">{error}</p>
                <button
                  onClick={() => navigator.clipboard.writeText(error)}
                  className="text-xs text-red-600 hover:text-red-800 mt-1 underline"
                >
                  Copy error details
                </button>
              </div>
            </div>
          </div>
        )}

        {/* System Health Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-600" />
              System Health Checks
            </h2>
            {isLoading && systemHealth.length === 0 ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
                <p className="text-gray-600 mt-2">Loading health checks...</p>
              </div>
            ) : systemHealth.length > 0 ? (
              <div className="space-y-3">
                {systemHealth.map((check, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border ${getStatusColor(check.status)}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        {getStatusIcon(check.status)}
                        <div>
                          <h3 className="font-semibold">{check.component}</h3>
                          <p className="text-sm mt-1">{check.message}</p>
                        </div>
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-white bg-opacity-50">
                        {check.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Database className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No health check data available</p>
              </div>
            )}
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Database className="w-5 h-5 text-indigo-600" />
              Environment Validation
            </h2>
            {isLoading && envChecks.length === 0 ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
                <p className="text-gray-600 mt-2">Validating environment...</p>
              </div>
            ) : envChecks.length > 0 ? (
              <div className="space-y-3">
                {envChecks.map((check, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border ${getStatusColor(check.status)}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        {getStatusIcon(check.status)}
                        <div>
                          <h3 className="font-semibold">{check.check_name}</h3>
                          <p className="text-sm mt-1">{check.details}</p>
                        </div>
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-white bg-opacity-50">
                        {check.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Server className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No validation data available</p>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Diagnostics</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => fetchSystemHealth()}
              className="p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors text-left"
            >
              <TrendingUp className="w-6 h-6 text-indigo-600 mb-2" />
              <h3 className="font-semibold text-gray-900">Run Health Check</h3>
              <p className="text-sm text-gray-600 mt-1">Perform full system health diagnostic</p>
            </button>
            
            <button
              onClick={() => window.location.href = '/role-based-dashboard-hub'}
              className="p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors text-left"
            >
              <Users className="w-6 h-6 text-indigo-600 mb-2" />
              <h3 className="font-semibold text-gray-900">Test Navigation</h3>
              <p className="text-sm text-gray-600 mt-1">Verify home page and navigation routes</p>
            </button>
            
            <button
              onClick={() => window.location.href = '/study-rooms'}
              className="p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors text-left"
            >
              <Activity className="w-6 h-6 text-indigo-600 mb-2" />
              <h3 className="font-semibold text-gray-900">Test Study Rooms</h3>
              <p className="text-sm text-gray-600 mt-1">Verify study room join/create functionality</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemIntegrationPerformanceMonitor;