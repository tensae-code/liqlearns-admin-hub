import { supabase } from '../lib/supabase';

/**
 * Stripe Service for handling subscription payments
 * 
 * IMPORTANT SETUP STEPS:
 * 1. Add VITE_STRIPE_PUBLISHABLE_KEY to your .env file
 * 2. Install Stripe: npm install @stripe/stripe-js
 * 3. Create products and prices in Stripe Dashboard (Test Mode)
 * 4. Update subscription_plans table with stripe_price_id_monthly values
 * 5. Set up Stripe webhook endpoint in Supabase Edge Functions
 */

// Interface for subscription plan
export interface SubscriptionPlan {
  id: string;
  name: string;
  price_monthly: number;
  price_yearly: number;
  currency: string;
  features: any;
  is_active: boolean;
  stripe_price_id_monthly: string | null;
  stripe_price_id_yearly: string | null;
}

// Interface for checkout session creation
export interface CheckoutSessionParams {
  priceId: string;
  userId: string;
  email: string;
  successUrl: string;
  cancelUrl: string;
  metadata?: Record<string, string>;
}

export interface CreateCheckoutSessionParams {
  lineItems: Array<{
    price_data: {
      currency: string;
      product_data: {
        name: string;
        description?: string;
        images?: string[];
      };
      unit_amount: number;
    };
    quantity: number;
  }>;
  successUrl: string;
  cancelUrl: string;
}

const getSuccessUrl = (): string => {
  const isProduction = import.meta.env.PROD;
  
  if (isProduction) {
    return import.meta.env.VITE_PRODUCTION_SUCCESS_URL || 
           `${import.meta.env.VITE_PRODUCTION_APP_URL}/success` ||
           'https://liqlearns.com/success';
  }
  
  return import.meta.env.VITE_SUCCESS_URL || 'http://localhost:5173/success';
};

const getCancelUrl = (): string => {
  const isProduction = import.meta.env.PROD;
  
  if (isProduction) {
    return import.meta.env.VITE_PRODUCTION_CANCEL_URL || 
           `${import.meta.env.VITE_PRODUCTION_APP_URL}/cancel` ||
           'https://liqlearns.com/cancel';
  }
  
  return import.meta.env.VITE_CANCEL_URL || 'http://localhost:5173/cancel';
};

/**
 * Fetch all active subscription plans from database
 */
export const fetchSubscriptionPlans = async (): Promise<SubscriptionPlan[]> => {
  try {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('is_active', true)
      .order('price_monthly', { ascending: true });
    
    if (error) throw error;
    
    return data || [];
  } catch (error) {
    console.error('Error fetching subscription plans:', error);
    throw error;
  }
};

/**
 * Create Stripe customer for a user
 * This should be called when user signs up
 */
export const createStripeCustomer = async (
  userId: string,
  email: string,
  name: string
): Promise<string | null> => {
  try {
    // Call Supabase Edge Function to create Stripe customer
    const { data, error } = await supabase.functions.invoke('create-stripe-customer', {
      body: {
        userId,
        email,
        name
      }
    });
    
    if (error) throw error;
    
    // Update student_profiles with Stripe customer ID
    if (data?.customerId) {
      await supabase
        .from('student_profiles')
        .update({ stripe_customer_id: data.customerId })
        .eq('id', userId);
      
      return data.customerId;
    }
    
    return null;
  } catch (error) {
    console.error('Error creating Stripe customer:', error);
    return null;
  }
};

/**
 * Create Stripe checkout session for marketplace purchases
 */
export const createCheckoutSession = async (params: CreateCheckoutSessionParams) => {
  try {
    const { data, error } = await supabase.functions.invoke('create-checkout-session', {
      body: params
    });

    if (error) throw error;
    
    return data as { sessionId: string; url: string };
  } catch (error: any) {
    console.error('Error creating checkout session:', error);
    throw new Error(error.message || 'Failed to create checkout session');
  }
};

/**
 * Get customer portal URL for managing subscriptions
 */
export const getCustomerPortalUrl = async (
  customerId: string,
  returnUrl: string
): Promise<string | null> => {
  try {
    const { data, error } = await supabase.functions.invoke('create-customer-portal', {
      body: {
        customerId,
        returnUrl
      }
    });
    
    if (error) throw error;
    
    return data?.portalUrl || null;
  } catch (error) {
    console.error('Error creating customer portal:', error);
    return null;
  }
};

/**
 * Get user's current subscription status
 */
export const getUserSubscription = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('student_profiles')
      .select(`
        stripe_subscription_id,
        subscription_plan,
        subscription_start_date,
        subscription_end_date,
        has_active_subscription
      `)
      .eq('id', userId)
      .maybeSingle();
    
    if (error) throw error;
    
    // Return null if no profile found, otherwise return the subscription data
    return data;
  } catch (error) {
    console.error('Error fetching user subscription:', error);
    return null;
  }
};

/**
 * Cancel subscription at period end
 */
export const cancelSubscription = async (
  subscriptionId: string
): Promise<boolean> => {
  try {
    const { data, error } = await supabase.functions.invoke('cancel-subscription', {
      body: { subscriptionId }
    });
    
    if (error) throw error;
    
    return data?.success || false;
  } catch (error) {
    console.error('Error canceling subscription:', error);
    return false;
  }
};

/**
 * Resume canceled subscription
 */
export const resumeSubscription = async (
  subscriptionId: string
): Promise<boolean> => {
  try {
    const { data, error } = await supabase.functions.invoke('resume-subscription', {
      body: { subscriptionId }
    });
    
    if (error) throw error;
    
    return data?.success || false;
  } catch (error) {
    console.error('Error resuming subscription:', error);
    return false;
  }
};

// Export service object with all methods
export const stripeService = {
  fetchSubscriptionPlans,
  createStripeCustomer,
  createCheckoutSession,
  getCustomerPortalUrl,
  getUserSubscription,
  cancelSubscription,
  resumeSubscription
};