import { supabase } from '../lib/supabase';

export { supabase };
