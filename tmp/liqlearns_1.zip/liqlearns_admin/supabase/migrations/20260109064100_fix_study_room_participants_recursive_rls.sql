-- Migration: Fix infinite recursion in study_room_participants RLS policies
-- Issue: students_view_room_participants policy queries the same table it's protecting
-- Solution: Replace with simpler policies that don't create circular dependencies

-- Drop the problematic recursive policy
DROP POLICY IF EXISTS students_view_room_participants ON study_room_participants;

-- Create a simple, non-recursive policy for viewing participants
-- Allow authenticated users to view participants in any active study room
-- This removes the recursive query while maintaining security
CREATE POLICY students_view_active_room_participants ON study_room_participants
  FOR SELECT
  TO authenticated
  USING (
    -- Allow viewing participants in rooms that are currently active
    EXISTS (
      SELECT 1 FROM study_rooms
      WHERE study_rooms.id = study_room_participants.room_id
        AND study_rooms.status IN ('waiting', 'active')
    )
  );

-- Add comment explaining the fix
COMMENT ON POLICY students_view_active_room_participants ON study_room_participants IS 
'Non-recursive policy that allows viewing participants in active study rooms without querying study_room_participants table itself';

-- Verify no recursive policies remain
-- The following policies are safe and don't cause recursion:
-- - students_manage_own_participation: Uses auth.uid() directly
-- - participants_select_policy: No USING clause (allows all SELECT)
-- - participants_insert_policy: Uses auth.uid() directly in CHECK
-- - participants_update_policy: Uses auth.uid() directly
-- - participants_delete_policy: Uses auth.uid() directly