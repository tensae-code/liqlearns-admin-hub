-- Fix duplicate key error when rejoining study rooms
-- Problem: The unique constraint on (room_id, student_id) prevents users from rejoining
-- a room after leaving, even though left_at is populated
-- Solution: Replace with a partial unique index that only enforces uniqueness for active participants

-- Drop the existing unique constraint
ALTER TABLE study_room_participants
DROP CONSTRAINT IF EXISTS study_room_participants_room_id_student_id_key;

-- Create a partial unique index that only applies to active participants (left_at IS NULL)
-- This allows multiple historical records per user/room but only one active participation
CREATE UNIQUE INDEX IF NOT EXISTS study_room_participants_active_participation_unique
ON study_room_participants (room_id, student_id)
WHERE left_at IS NULL;

-- Add helpful comment
COMMENT ON INDEX study_room_participants_active_participation_unique IS 
'Ensures a student can only have one active participation per room (left_at IS NULL), but allows historical records of past participations';