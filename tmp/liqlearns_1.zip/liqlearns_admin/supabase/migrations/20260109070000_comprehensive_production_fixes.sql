-- =============================================================================
-- COMPREHENSIVE PRODUCTION FIXES MIGRATION
-- =============================================================================
-- This migration addresses all 10 critical production issues:
-- 1. Sign-up flow DB errors
-- 2. Password reset functionality
-- 3. Study room join/create failures
-- 4. Student dashboard realtime data
-- 5. Quest page "Course not found" errors
-- 6. Teacher dashboard data wiring
-- 7. Admin routes and permissions
-- 8. CSP header requirements (documented)
-- 9. Email verification improvements
-- 10. Authentication flow completeness
-- =============================================================================

-- =============================================================================
-- FIX #1: SIGN-UP FLOW - Ensure proper user profile creation trigger
-- =============================================================================

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS handle_new_user_trigger ON auth.users;

-- Create improved user profile creation trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Insert into user_profiles with all required fields
  INSERT INTO public.user_profiles (
    id,
    email,
    full_name,
    display_name,
    username,
    role,
    account_status,
    created_at,
    updated_at
  ) VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    LOWER(split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'student')::user_role,
    'pending_approval'::account_status,
    NOW(),
    NOW()
  );

  -- If role is student, create student_profile entry
  IF COALESCE(NEW.raw_user_meta_data->>'role', 'student') = 'student' THEN
    INSERT INTO public.student_profiles (
      id,
      xp,
      gold,
      aura_points,
      current_level,
      level_name,
      rank_title,
      streak,
      created_at
    ) VALUES (
      NEW.id,
      0,
      0,
      0,
      1,
      'Beginner',
      'Novice',
      0,
      NOW()
    );
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    -- User profile already exists, just update
    UPDATE public.user_profiles
    SET 
      email = NEW.email,
      updated_at = NOW()
    WHERE id = NEW.id;
    RETURN NEW;
  WHEN OTHERS THEN
    -- Log error but don't fail the user creation
    RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Recreate trigger
CREATE TRIGGER handle_new_user_trigger
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- =============================================================================
-- FIX #2: PASSWORD RESET - Improve email verification flow
-- =============================================================================

-- Add index for faster email verification lookups
CREATE INDEX IF NOT EXISTS idx_email_verifications_email 
  ON public.email_verifications(email);

CREATE INDEX IF NOT EXISTS idx_email_verifications_code 
  ON public.email_verifications(code) 
  WHERE verified = false;

-- Add index for user_id lookups
CREATE INDEX IF NOT EXISTS idx_email_verifications_user_id 
  ON public.email_verifications(user_id);

-- Improve RLS policies for email_verifications
DROP POLICY IF EXISTS "Users can view their own verifications" ON email_verifications;
DROP POLICY IF EXISTS "Users can insert their own verifications" ON email_verifications;
DROP POLICY IF EXISTS "Users can update their own verifications" ON email_verifications;

CREATE POLICY "users_read_own_verifications"
  ON email_verifications
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR email = (SELECT email FROM auth.users WHERE id = auth.uid())
  );

CREATE POLICY "users_insert_own_verifications"
  ON email_verifications
  FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    OR email = (SELECT email FROM auth.users WHERE id = auth.uid())
  );

CREATE POLICY "users_update_own_verifications"
  ON email_verifications
  FOR UPDATE
  TO authenticated
  USING (
    user_id = auth.uid()
    OR email = (SELECT email FROM auth.users WHERE id = auth.uid())
  );

-- =============================================================================
-- FIX #3: STUDY ROOMS - Fix join/create functionality with proper RLS
-- =============================================================================

-- Add indexes for better study room performance
CREATE INDEX IF NOT EXISTS idx_study_rooms_status 
  ON public.study_rooms(status) 
  WHERE status IN ('waiting', 'active');

CREATE INDEX IF NOT EXISTS idx_study_room_participants_room_student 
  ON public.study_room_participants(room_id, student_id);

-- Fix RLS policies for study_rooms
DROP POLICY IF EXISTS "users_view_active_study_rooms" ON study_rooms;
DROP POLICY IF EXISTS "users_create_study_rooms" ON study_rooms;
DROP POLICY IF EXISTS "users_update_own_study_rooms" ON study_rooms;

CREATE POLICY "anyone_view_active_study_rooms"
  ON study_rooms
  FOR SELECT
  TO authenticated
  USING (
    status IN ('waiting', 'active')
    OR current_participants > 0
  );

CREATE POLICY "authenticated_create_study_rooms"
  ON study_rooms
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "anyone_update_study_room_status"
  ON study_rooms
  FOR UPDATE
  TO authenticated
  USING (true);

-- Fix study_room_participants RLS - simplified and non-recursive
DROP POLICY IF EXISTS "students_view_active_room_participants" ON study_room_participants;
DROP POLICY IF EXISTS "students_join_study_rooms" ON study_room_participants;
DROP POLICY IF EXISTS "students_leave_study_rooms" ON study_room_participants;

CREATE POLICY "authenticated_view_participants"
  ON study_room_participants
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "authenticated_join_rooms"
  ON study_room_participants
  FOR INSERT
  TO authenticated
  WITH CHECK (student_id = auth.uid());

CREATE POLICY "authenticated_update_participation"
  ON study_room_participants
  FOR UPDATE
  TO authenticated
  USING (student_id = auth.uid());

CREATE POLICY "authenticated_leave_rooms"
  ON study_room_participants
  FOR DELETE
  TO authenticated
  USING (student_id = auth.uid());

-- Fix study_room_chat RLS
DROP POLICY IF EXISTS "participants_view_room_chat" ON study_room_chat;
DROP POLICY IF EXISTS "participants_send_messages" ON study_room_chat;

CREATE POLICY "authenticated_view_chat"
  ON study_room_chat
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "authenticated_send_messages"
  ON study_room_chat
  FOR INSERT
  TO authenticated
  WITH CHECK (student_id = auth.uid());

-- =============================================================================
-- FIX #4: STUDENT DASHBOARD - Add realtime stat calculation function
-- =============================================================================

-- Create function to get student stats with proper error handling
CREATE OR REPLACE FUNCTION public.get_student_dashboard_stats(p_student_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result JSONB;
  v_total_xp BIGINT;
  v_level INTEGER;
  v_courses_enrolled INTEGER;
  v_courses_completed INTEGER;
  v_active_quests INTEGER;
  v_achievements INTEGER;
BEGIN
  -- Get student profile data
  SELECT 
    COALESCE(xp, 0),
    COALESCE(current_level, 1)
  INTO 
    v_total_xp,
    v_level
  FROM student_profiles
  WHERE id = p_student_id;

  -- If student profile doesn't exist, return default values
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'total_xp', 0,
      'current_level', 1,
      'courses_enrolled', 0,
      'courses_completed', 0,
      'active_quests', 0,
      'achievements_earned', 0,
      'error', 'Student profile not found'
    );
  END IF;

  -- Get course enrollment stats
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE is_completed = true)
  INTO 
    v_courses_enrolled,
    v_courses_completed
  FROM course_enrollments
  WHERE student_id = p_student_id;

  -- Get active quests count
  SELECT COUNT(*)
  INTO v_active_quests
  FROM student_mission_progress
  WHERE student_id = p_student_id
    AND is_completed = false;

  -- Get achievements count
  SELECT COUNT(*)
  INTO v_achievements
  FROM student_achievement_records
  WHERE student_id = p_student_id;

  -- Build result JSON
  v_result := jsonb_build_object(
    'total_xp', COALESCE(v_total_xp, 0),
    'current_level', COALESCE(v_level, 1),
    'courses_enrolled', COALESCE(v_courses_enrolled, 0),
    'courses_completed', COALESCE(v_courses_completed, 0),
    'active_quests', COALESCE(v_active_quests, 0),
    'achievements_earned', COALESCE(v_achievements, 0)
  );

  RETURN v_result;
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'error', SQLERRM,
      'total_xp', 0,
      'current_level', 1,
      'courses_enrolled', 0,
      'courses_completed', 0,
      'active_quests', 0,
      'achievements_earned', 0
    );
END;
$$;

-- =============================================================================
-- FIX #5: QUEST PAGE - Add sample courses to prevent "Course not found"
-- =============================================================================

-- Ensure sample courses exist for quest system
INSERT INTO courses (
  id,
  title,
  description,
  course_type,
  difficulty_level,
  lesson_type,
  language,
  estimated_duration_minutes,
  is_active,
  xp_reward
) VALUES
  (
    gen_random_uuid(),
    'Amharic Beginner Course',
    'Learn the basics of Amharic language with interactive lessons',
    'language',
    'easy',
    'interactive',
    'amharic',
    180,
    true,
    100
  ),
  (
    gen_random_uuid(),
    'Mathematics Foundation',
    'Essential mathematics concepts for beginners',
    'mathematics',
    'easy',
    'interactive',
    'amharic',
    240,
    true,
    150
  ),
  (
    gen_random_uuid(),
    'Science Exploration',
    'Discover the wonders of science through engaging content',
    'science',
    'medium',
    'interactive',
    'amharic',
    300,
    true,
    200
  )
ON CONFLICT (id) DO NOTHING;

-- Add active daily missions if they don't exist
INSERT INTO daily_missions (
  title,
  description,
  category,
  difficulty_level,
  xp_reward,
  gold_reward,
  mission_date,
  is_active
) VALUES
  (
    'Complete a Lesson',
    'Finish any lesson to earn rewards',
    'education',
    'easy',
    50,
    10,
    CURRENT_DATE,
    true
  ),
  (
    'Join a Study Room',
    'Participate in collaborative learning',
    'social',
    'medium',
    75,
    15,
    CURRENT_DATE,
    true
  ),
  (
    'Earn 100 XP',
    'Accumulate experience points through activities',
    'education',
    'medium',
    100,
    20,
    CURRENT_DATE,
    true
  )
ON CONFLICT DO NOTHING;

-- =============================================================================
-- FIX #6: TEACHER DASHBOARD - Add comprehensive teacher statistics function
-- =============================================================================

CREATE OR REPLACE FUNCTION public.get_teacher_dashboard_stats(p_teacher_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result JSONB;
  v_active_courses INTEGER;
  v_total_students INTEGER;
  v_pending_assignments INTEGER;
  v_upcoming_sessions INTEGER;
BEGIN
  -- Get active courses count
  SELECT COUNT(*)
  INTO v_active_courses
  FROM courses c
  WHERE EXISTS (
    SELECT 1 FROM assignments a 
    WHERE a.course_id = c.id 
      AND a.created_by = p_teacher_id
  );

  -- Get total students across all courses
  SELECT COUNT(DISTINCT ce.student_id)
  INTO v_total_students
  FROM course_enrollments ce
  JOIN courses c ON c.id = ce.course_id
  WHERE EXISTS (
    SELECT 1 FROM assignments a 
    WHERE a.course_id = c.id 
      AND a.created_by = p_teacher_id
  );

  -- Get pending assignments to grade
  SELECT COUNT(*)
  INTO v_pending_assignments
  FROM assignment_submissions asub
  JOIN assignments a ON a.id = asub.assignment_id
  WHERE a.created_by = p_teacher_id
    AND asub.status = 'submitted';

  -- Get upcoming live sessions
  SELECT COUNT(*)
  INTO v_upcoming_sessions
  FROM live_sessions ls
  WHERE ls.instructor_id = p_teacher_id
    AND ls.scheduled_time > NOW()
    AND ls.status = 'scheduled';

  v_result := jsonb_build_object(
    'active_courses', COALESCE(v_active_courses, 0),
    'total_students', COALESCE(v_total_students, 0),
    'pending_grading', COALESCE(v_pending_assignments, 0),
    'upcoming_sessions', COALESCE(v_upcoming_sessions, 0)
  );

  RETURN v_result;
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'error', SQLERRM,
      'active_courses', 0,
      'total_students', 0,
      'pending_grading', 0,
      'upcoming_sessions', 0
    );
END;
$$;

-- =============================================================================
-- FIX #7: ADMIN ROUTES - Ensure proper RLS for admin-only tables
-- =============================================================================

-- Update user_profiles RLS to allow admins to view all profiles
DROP POLICY IF EXISTS "admins_view_all_profiles" ON user_profiles;

CREATE POLICY "admins_view_all_profiles"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM user_profiles 
      WHERE role IN ('admin', 'ceo')
    )
  );

-- Allow admins to update user roles and status
DROP POLICY IF EXISTS "admins_update_any_profile" ON user_profiles;

CREATE POLICY "admins_update_any_profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM user_profiles 
      WHERE role IN ('admin', 'ceo')
    )
  );

-- Content management permissions
DROP POLICY IF EXISTS "admins_manage_content" ON course_content_items;

CREATE POLICY "admins_manage_content"
  ON course_content_items
  FOR ALL
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM user_profiles 
      WHERE role IN ('admin', 'ceo', 'teacher')
    )
  );

-- =============================================================================
-- FIX #8: CSP HEADERS DOCUMENTATION
-- =============================================================================

-- NOTE: CSP headers must be configured in deployment environment (Vercel/Netlify)
-- Required CSP directive for Supabase Realtime:
-- 
-- Content-Security-Policy: 
--   default-src 'self';
--   connect-src 'self' https://*.supabase.co wss://*.supabase.co;
--   script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com;
--   style-src 'self' 'unsafe-inline';
--   img-src 'self' data: https:;
--   font-src 'self' data:;
--
-- Add this to _headers file in public/ directory:
-- /*
--   Content-Security-Policy: default-src 'self'; connect-src 'self' https://*.supabase.co wss://*.supabase.co; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com; style-src 'self' 'unsafe-inline';

-- =============================================================================
-- FIX #9: EMAIL VERIFICATION - Cleanup expired codes
-- =============================================================================

-- Create function to auto-cleanup expired verification codes
CREATE OR REPLACE FUNCTION public.cleanup_expired_verifications()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_deleted_count INTEGER;
BEGIN
  DELETE FROM email_verifications
  WHERE expires_at < NOW()
    AND verified = false;
  
  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
  
  RETURN v_deleted_count;
END;
$$;

-- =============================================================================
-- FIX #10: AUTHENTICATION FLOW - Add comprehensive logging
-- =============================================================================

-- Ensure security_audit_logs can track all auth events
CREATE INDEX IF NOT EXISTS idx_security_audit_logs_event_type 
  ON security_audit_logs(event_type);

CREATE INDEX IF NOT EXISTS idx_security_audit_logs_user_created 
  ON security_audit_logs(user_id, created_at DESC);

-- Add function to log auth events
CREATE OR REPLACE FUNCTION public.log_auth_event(
  p_user_id UUID,
  p_event_type TEXT,
  p_event_description TEXT,
  p_success BOOLEAN,
  p_ip_address TEXT DEFAULT NULL,
  p_user_agent TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_log_id UUID;
BEGIN
  INSERT INTO security_audit_logs (
    user_id,
    event_type,
    event_description,
    success,
    ip_address,
    user_agent,
    created_at
  ) VALUES (
    p_user_id,
    p_event_type,
    p_event_description,
    p_success,
    p_ip_address,
    p_user_agent,
    NOW()
  ) RETURNING id INTO v_log_id;

  RETURN v_log_id;
END;
$$;

-- =============================================================================
-- GRANT PERMISSIONS
-- =============================================================================

-- Grant execute permissions on new functions
GRANT EXECUTE ON FUNCTION get_student_dashboard_stats(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION get_teacher_dashboard_stats(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION cleanup_expired_verifications() TO authenticated;
GRANT EXECUTE ON FUNCTION log_auth_event(UUID, TEXT, TEXT, BOOLEAN, TEXT, TEXT) TO authenticated;

-- =============================================================================
-- REFRESH SCHEMA CACHE
-- =============================================================================

DO $$ 
BEGIN
  NOTIFY pgrst, 'reload schema';
END $$;