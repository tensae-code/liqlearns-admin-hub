-- =====================================================
-- Migration: Fix User Profiles Infinite Recursion RLS
-- =====================================================
-- Issue: Infinite recursion detected in policy for relation "user_profiles"
-- Root Cause: RLS policies querying user_profiles table create circular dependency
-- Solution: Drop recursive policies, rely on SECURITY DEFINER function

-- Drop the problematic recursive RLS policies
DROP POLICY IF EXISTS "admins_view_all_profiles" ON public.user_profiles;
DROP POLICY IF EXISTS "admins_update_any_profile" ON public.user_profiles;

-- The correct policy already exists: admins_view_all_user_profiles
-- This policy uses is_admin_or_ceo() which has SECURITY DEFINER
-- SECURITY DEFINER runs with function owner's privileges, bypassing RLS
-- This prevents infinite recursion

-- Verify the good policy still exists (no-op, just for documentation)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'user_profiles' 
    AND policyname = 'admins_view_all_user_profiles'
  ) THEN
    -- Create the correct policy if it doesn't exist
    CREATE POLICY "admins_view_all_user_profiles"
      ON public.user_profiles
      FOR SELECT
      TO authenticated
      USING (is_admin_or_ceo());
  END IF;
END $$;

-- Add proper admin UPDATE policy using SECURITY DEFINER function
CREATE POLICY "admins_update_user_profiles"
  ON public.user_profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin_or_ceo())
  WITH CHECK (is_admin_or_ceo());

-- Summary of final RLS policies on user_profiles:
-- 1. users_manage_own_user_profiles: Users can manage their own profile (id = auth.uid())
-- 2. admins_view_all_user_profiles: Admins/CEOs can view all profiles (uses SECURITY DEFINER function)
-- 3. admins_update_user_profiles: Admins/CEOs can update all profiles (uses SECURITY DEFINER function)